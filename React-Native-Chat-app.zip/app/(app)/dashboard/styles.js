import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container:{
        flex:1
    },
    loading:{
        display:'flex',
        alignItems:'center',
        paddingTop:'50%'
    }
})