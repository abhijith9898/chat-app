import { View, Text } from 'react-native'
import React from 'react'

export default function Settings() {
  return (
    <View>
      <Text>Settings</Text>
    </View>
  )
}